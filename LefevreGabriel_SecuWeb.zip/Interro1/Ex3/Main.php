<?php
/**
 * Created by PhpStorm.
 * User: gabriel.lefevre
 * Date: 14/11/16
 * Time: 11:22
 */

require_once("Equipe.php");
require_once("Football.php");
require_once("Tennis.php");

$F = new Football("AZERTY",0,"RCL");

echo $F;